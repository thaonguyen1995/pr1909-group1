CKEDITOR.plugins.setLang('video', 'fr', {
  button: 'Vidéo',
  title: 'Propriétés de la vidéo',
  emptySrc: 'L’URL doit être indiquée.',
  controls: 'Activer les contrôles',
  mutedLoopingAutoplay: 'Lecture automatique en boucle et muette',
  preview: 'Aperçu',
  invalidSrc: 'L’URL est invalide ou la vidéo n’est pas lisible.'
});
