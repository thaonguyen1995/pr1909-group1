/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image', 'ku', {
	alt: 'جێگرەوەی دەق',
	border: 'پەراوێز',
	btnUpload: 'ناردنی بۆ ڕاژه',
	button2Img: 'تۆ دەتەوێت دوگمەی وێنەی دیاریکراو بگۆڕیت بۆ وێنەیەکی ئاسایی؟',
	hSpace: 'بۆشایی ئاسۆیی',
	img2Button: 'تۆ دەتەوێت وێنەی دیاریکراو بگۆڕیت بۆ دوگمەی وێنه؟',
	infoTab: 'زانیاری وێنه',
	linkTab: 'بەستەر',
	lockRatio: 'داخستنی ڕێژه',
	menu: 'خاسیەتی وێنه',
	resetSize: 'ڕێکخستنەوەی قەباره',
	title: 'خاسیەتی وێنه',
	titleButton: 'خاسیەتی دوگمەی وێنه',
	upload: 'بارکردن',
	urlMissing: 'سەرچاوەی بەستەری وێنه بزره',
	vSpace: 'بۆشایی ئەستونی',
	validateBorder: 'پەراوێز دەبێت بەتەواوی تەنها ژماره بێت.',
	validateHSpace: 'بۆشایی ئاسۆیی دەبێت بەتەواوی تەنها ژمارە بێت.',
	validateVSpace: 'بۆشایی ئەستونی دەبێت بەتەواوی تەنها ژماره بێت.'
} );
