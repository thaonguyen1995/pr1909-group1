/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image', 'mk', {
	alt: 'Алтернативен текст',
	border: 'Раб',
	btnUpload: 'Прикачи на сервер',
	button2Img: 'Дали сакате да направите сликата-копче да биде само слика?',
	hSpace: 'Хоризонтален простор',
	img2Button: 'Дали сакате да ја претворите сликата во слика-копче?',
	infoTab: 'Информации за сликата',
	linkTab: 'Врска',
	lockRatio: 'Зачувај пропорција',
	menu: 'Својства на сликата',
	resetSize: 'Ресетирај големина',
	title: 'Својства на сликата',
	titleButton: 'Својства на копче-сликата',
	upload: 'Прикачи',
	urlMissing: 'Недостасува URL-то на сликата.',
	vSpace: 'Вертикален простор',
	validateBorder: 'Работ мора да биде цел број.',
	validateHSpace: 'Хор. простор мора да биде цел број.',
	validateVSpace: 'Верт. простор мора да биде цел број.'
} );
